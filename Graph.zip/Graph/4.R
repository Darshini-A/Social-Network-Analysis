# Degree Centrality
# Closeness Centrality
# Betweeness Centrality for a given graph


library("igraph")

g = graph.formula(R-G, R-J, R-I, R-H, R-F, F-P, F-O, P-Q, P-O, O-Q, Q-C, C-O, C-D, D-Q)
plot(g)

centralization.degree(g, mode = "in")
centralization.closeness(g, mode = "all")

closeness(g, mode = "all", weights = NA)

betweenness(g, directed = F, weights = NA)
