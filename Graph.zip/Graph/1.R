# Number of edges
# Number of nodes
# Degree of node
# Node with lowest degree
# Adjacency matrix


install.packages("igraph")
library('igraph')

g = graph.formula(1-2, 1-3, 2-3, 2-4, 3-5, 4-5, 4-6, 4-7, 5-6, 6-7)
plot(g)

g1 = graph.formula(1-+2, 1-+3, 2++3)
plot(g1)

ecount(g)
ecount(g1)

vcount(g)
vcount(g1)

degree(g)
degree(g1)

min(degree(g))

V(g)$name[degree(g) == min(degree(g))]
V(g1)$name[degree(g1) == min(degree(g1))]

plot(g)
get.adjacency(g)