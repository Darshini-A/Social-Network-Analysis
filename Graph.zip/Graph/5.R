# Length of shortest path from given node to another node
# Density of the graph


library('igraph')

matt = as.matrix(read.table(text="
node A B C D E F
A    0 2 3 0 5 0
B    2 0 0 6 0 0
C    0 0 0 0 0 4
D    0 0 3 0 0 0
E    0 0 0 0 0 3
F    0 0 0 0 3 0", header = T))

nms = matt[,1]
matt = matt[,-1]
matt

g = graph.adjacency(matt,weighted = TRUE)
plot(g,edge.label = E(g)$weight)

s.path = shortest.paths(g,algorithm = "dijkstra")
shortest.paths(g, v="A", to="F")
shortest.paths(g, v="B", to="F")
shortest.paths(g, v="A", to="C")

graph.density(g, loops = TRUE)