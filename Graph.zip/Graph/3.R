# Density
# Degree
# Reciprocity
# Transitivity index
# Transitivity Census


library("igraph")

g = graph.formula(1-2, 1-3, 2-3, 2-4, 3-5, 4-5, 4-6, 4-7, 5-6, 6-7)
plot(g)

nd = vcount(g)
nd

ed = ecount(g)
ed

density = ed/(nd*(nd-1)/2)
density

degree(g)
  
reciprocity(g)
  
dyad_census(g)

transitivity(g, type = 'local')