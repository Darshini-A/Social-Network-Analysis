# Write a program :
# to distinguish a network as a matrix
# network as an edge list
# network as a sociogram(network graph) using three distinct network representations


library("igraph")

ng = graph.formula(andy++john, john-+bill, bill-+elena, elena++frank, carol-+andy, carol++dan, carol++bill, dan++andy, dan++bill)
plot(ng)

get.adjacency(ng)

get.adjedgelist(ng)