# View data collection and import data from excel
# Create a social graph of imported data


library('igraph')

getwd()

nodes = read.csv("Dataset1-Media-Example-NODES.csv",header=T,as.is=T)
head(nodes)

link = read.csv("Dataset1-Media-Example-EDGES.csv",header=T,as.is=T)
head(link)

mediagraph = graph.data.frame(d=link, vertices=nodes,directed=T)
get.adjacency(mediagraph)
plot(mediagraph)