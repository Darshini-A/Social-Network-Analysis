# Full graph
# Ring graph
# Star graph
# Random graph


library(igraph)

fg = make_full_graph(6, loops = FALSE, directed = FALSE)
plot(fg)

rg = make_ring(8, directed = TRUE, mutual = TRUE, circular = TRUE)
plot(rg)

sg = make_star(6, mode = "in",center = 1)
plot(sg)

rdg = sample_gnp(8, 0.6, directed = FALSE, loops = FALSE)
plot(rdg)