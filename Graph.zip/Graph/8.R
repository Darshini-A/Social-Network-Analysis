# Cliques in a network
# Components in a network
# Random walk on a graph
# Change the color of vertices and edges
# Save the graph in the form of an edge list on your computer.


install.packages("igraph")
library(igraph)

fg = make_full_graph(6, loops = FALSE, directed = FALSE)
plot(fg)

cliques(fg, min = 3)
components(fg)
random_walk(fg, 1, 6)

g2 = sample_gnp(6, 0.6, directed = FALSE, loops = FALSE) %>% 
  set_vertex_attr("color", value = "yellow") %>% 
  set_edge_attr("color",value="red")
plot(g2)

getwd()
write.graph(g2, "Graph2-8.txt", format = "edgelist")