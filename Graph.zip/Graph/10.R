# Clustering


install.packages("factoextra")
library(factoextra)

df = mtcars
df = na.omit(df)
df = scale(df)

png(file = "Cluster Example-10.png")

km = kmeans(df, centers = 4, nstart = 25)
fviz_cluster(km, data = df)

dev.off()
getwd()