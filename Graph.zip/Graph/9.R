# Hamming distance 
# Euclidean distance
# Manhattan distance


vec1 = c(10, 2, 3, 7, 8, 12)
vec2 = c(10, 2, 1, 2, 0, 24)

hd = sum(vec1 != vec2)
hd

vec3 = c(2, 4, 4, 7)
vec4 = c(1, 2, 2, 10)

caled = function(vec3, vec4) sqrt(sum(vec3 - vec4))
caled(vec3, vec4)

md = function(v1, v2) sum(abs(v1 - v2))
md(vec1, vec2)